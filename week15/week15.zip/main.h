# ifndef MAIN_H
# define MAIN_H

# include "space.h"
# include<stdlib.h>
# include<stdio.h>
# include<string.h>

#endif 